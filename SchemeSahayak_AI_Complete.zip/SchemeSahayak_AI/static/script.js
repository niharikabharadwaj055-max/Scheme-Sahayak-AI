const translations = {
  en: {
    eyebrow:"ONE PLACE • MANY SCHEMES", heroTitle:"Find government schemes made for you.",
    heroText:"Tell us a little about yourself. Scheme Sahayak matches your profile with schemes in our verified local database.",
    heroCardTitle:"Benefits, simplified.", heroCardText:"Discover eligibility, benefits, documents and official links without searching many portals.",
    finderEyebrow:"PERSONALISED FINDER", finderTitle:"Tell us about yourself", age:"Age", income:"Annual income (₹)",
    gender:"Gender", occupation:"Occupation", area:"Area", state:"State", category:"Main need",
    student:"I am a student", farmer:"I am a farmer", find:"Find My Schemes",
    f1:"Personalised", f1t:"Matches age, occupation, state and other profile signals.",
    f2:"Easy to understand", f2t:"Clear benefits, eligibility, documents and application steps.",
    f3:"AI Assistant", f3t:"Ask questions naturally in English, Kannada or Hindi."
  },
  kn: {
    eyebrow:"ಒಂದೇ ಸ್ಥಳ • ಅನೇಕ ಯೋಜನೆಗಳು", heroTitle:"ನಿಮಗಾಗಿ ಸೂಕ್ತ ಸರ್ಕಾರಿ ಯೋಜನೆಗಳನ್ನು ಹುಡುಕಿ.",
    heroText:"ನಿಮ್ಮ ಬಗ್ಗೆ ಕೆಲವು ಮಾಹಿತಿಯನ್ನು ನೀಡಿ. ಸ್ಕೀಮ್ ಸಹಾಯಕವು ನಿಮ್ಮ ಮಾಹಿತಿಯನ್ನು ನಮ್ಮ ಡೇಟಾಬೇಸ್‌ನ ಯೋಜನೆಗಳೊಂದಿಗೆ ಹೊಂದಿಸುತ್ತದೆ.",
    heroCardTitle:"ಸೌಲಭ್ಯಗಳನ್ನು ಸರಳಗೊಳಿಸಿ.", heroCardText:"ಅರ್ಹತೆ, ಪ್ರಯೋಜನಗಳು, ದಾಖಲೆಗಳು ಮತ್ತು ಅಧಿಕೃತ ಲಿಂಕ್‌ಗಳನ್ನು ಸುಲಭವಾಗಿ ನೋಡಿ.",
    finderEyebrow:"ವೈಯಕ್ತಿಕ ಹುಡುಕಾಟ", finderTitle:"ನಿಮ್ಮ ಬಗ್ಗೆ ತಿಳಿಸಿ", age:"ವಯಸ್ಸು", income:"ವಾರ್ಷಿಕ ಆದಾಯ (₹)",
    gender:"ಲಿಂಗ", occupation:"ಉದ್ಯೋಗ", area:"ಪ್ರದೇಶ", state:"ರಾಜ್ಯ", category:"ಮುಖ್ಯ ಅಗತ್ಯ",
    student:"ನಾನು ವಿದ್ಯಾರ್ಥಿ/ವಿದ್ಯಾರ್ಥಿನಿ", farmer:"ನಾನು ರೈತ", find:"ನನ್ನ ಯೋಜನೆಗಳನ್ನು ಹುಡುಕಿ",
    f1:"ವೈಯಕ್ತಿಕ", f1t:"ವಯಸ್ಸು, ಉದ್ಯೋಗ ಮತ್ತು ರಾಜ್ಯದ ಆಧಾರದ ಮೇಲೆ ಹೊಂದಿಸುತ್ತದೆ.",
    f2:"ಸರಳ ಮಾಹಿತಿ", f2t:"ಪ್ರಯೋಜನಗಳು, ಅರ್ಹತೆ, ದಾಖಲೆಗಳು ಮತ್ತು ಅರ್ಜಿ ಹಂತಗಳು.",
    f3:"AI ಸಹಾಯಕ", f3t:"ಕನ್ನಡ, ಹಿಂದಿ ಅಥವಾ ಇಂಗ್ಲಿಷ್‌ನಲ್ಲಿ ಪ್ರಶ್ನೆ ಕೇಳಿ."
  },
  hi: {
    eyebrow:"एक जगह • कई योजनाएं", heroTitle:"अपने लिए सही सरकारी योजनाएं खोजें।",
    heroText:"अपने बारे में थोड़ी जानकारी दें। स्कीम सहायक आपके प्रोफाइल को हमारे स्थानीय डेटाबेस की योजनाओं से मिलाता है।",
    heroCardTitle:"लाभ, आसान भाषा में।", heroCardText:"पात्रता, लाभ, दस्तावेज़ और आधिकारिक लिंक आसानी से देखें।",
    finderEyebrow:"व्यक्तिगत खोज", finderTitle:"अपने बारे में बताएं", age:"उम्र", income:"वार्षिक आय (₹)",
    gender:"लिंग", occupation:"व्यवसाय", area:"क्षेत्र", state:"राज्य", category:"मुख्य जरूरत",
    student:"मैं विद्यार्थी हूं", farmer:"मैं किसान हूं", find:"मेरी योजनाएं खोजें",
    f1:"व्यक्तिगत", f1t:"उम्र, व्यवसाय और राज्य के आधार पर मिलान करता है।",
    f2:"समझने में आसान", f2t:"लाभ, पात्रता, दस्तावेज़ और आवेदन की जानकारी।",
    f3:"AI सहायक", f3t:"हिंदी, कन्नड़ या अंग्रेज़ी में सवाल पूछें।"
  }
};

function setLanguage(lang){
  const t = translations[lang] || translations.en;
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const key = el.dataset.i18n;
    if(t[key]) el.textContent = t[key];
  });
  const hidden = document.getElementById("formLanguage");
  if(hidden) hidden.value = lang;
  localStorage.setItem("schemeLanguage", lang);
}

const selector = document.getElementById("language");
if(selector){
  const saved = localStorage.getItem("schemeLanguage") || "en";
  selector.value = saved;
  setLanguage(saved);
  selector.addEventListener("change", e=>setLanguage(e.target.value));
}
