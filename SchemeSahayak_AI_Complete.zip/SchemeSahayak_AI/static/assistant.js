const assistantTranslations = {
  en:{title:"Your government-scheme guide", text:"Ask about eligibility, benefits, documents or how to apply.", placeholder:"Ask about a government scheme..."},
  kn:{title:"ನಿಮ್ಮ ಸರ್ಕಾರಿ ಯೋಜನೆ ಮಾರ್ಗದರ್ಶಿ", text:"ಅರ್ಹತೆ, ಪ್ರಯೋಜನಗಳು, ದಾಖಲೆಗಳು ಅಥವಾ ಅರ್ಜಿ ಬಗ್ಗೆ ಕೇಳಿ.", placeholder:"ಸರ್ಕಾರಿ ಯೋಜನೆಯ ಬಗ್ಗೆ ಕೇಳಿ..."},
  hi:{title:"आपका सरकारी योजना सहायक", text:"पात्रता, लाभ, दस्तावेज़ या आवेदन के बारे में पूछें।", placeholder:"सरकारी योजना के बारे में पूछें..."}
};

function currentLang(){ return localStorage.getItem("schemeLanguage") || "en"; }

function applyAssistantLanguage(lang){
  const t = assistantTranslations[lang] || assistantTranslations.en;
  document.querySelectorAll("[data-i18n='chatTitle']").forEach(e=>e.textContent=t.title);
  document.querySelectorAll("[data-i18n='chatText']").forEach(e=>e.textContent=t.text);
  const input=document.getElementById("messageInput");
  if(input) input.placeholder=t.placeholder;
}

const langSel=document.getElementById("language");
if(langSel){
  const saved=currentLang();
  langSel.value=saved;
  applyAssistantLanguage(saved);
  langSel.addEventListener("change", e=>{
    localStorage.setItem("schemeLanguage", e.target.value);
    applyAssistantLanguage(e.target.value);
  });
}

function addBubble(text, type){
  const chatBox=document.getElementById("chatBox");
  const div=document.createElement("div");
  div.className=`bubble ${type}`;
  div.textContent=text;
  chatBox.appendChild(div);
  chatBox.scrollTop=chatBox.scrollHeight;
  return div;
}

function quickAsk(text){
  document.getElementById("messageInput").value=text;
  sendMessage();
}

async function sendMessage(){
  const input=document.getElementById("messageInput");
  const button=document.getElementById("sendButton");
  const message=input.value.trim();
  if(!message) return;

  addBubble(message,"user");
  input.value="";
  button.disabled=true;

  const thinking=addBubble("Thinking…","ai");

  try{
    const res=await fetch("/ai-chat",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message,language:{en:"English",kn:"Kannada",hi:"Hindi"}[currentLang()]})
    });
    const data=await res.json();
    thinking.textContent=data.reply || "I couldn't answer that.";
  }catch(err){
    thinking.textContent="Sorry, the AI service is unavailable right now.";
  }finally{
    button.disabled=false;
    input.focus();
  }
}

const input=document.getElementById("messageInput");
if(input){
  input.addEventListener("keydown",e=>{
    if(e.key==="Enter" && !e.shiftKey){
      e.preventDefault();
      sendMessage();
    }
  });
}
