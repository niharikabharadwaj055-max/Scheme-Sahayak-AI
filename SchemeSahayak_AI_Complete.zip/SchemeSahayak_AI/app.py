from flask import Flask, render_template, request, jsonify
import sqlite3
import os
from dotenv import load_dotenv

try:
    from google import genai
except ImportError:
    genai = None

from database import init_db, DB_NAME

load_dotenv()
app = Flask(__name__)

# Create/upgrade the database automatically when the server starts.
init_db()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
client = genai.Client(api_key=GEMINI_API_KEY) if (genai and GEMINI_API_KEY) else None

def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def scheme_matches(s, age, income, gender, occupation, location, category, state, student, farmer):
    # State filter
    if s["state"] not in ("ALL", state):
        return False

    # Age
    if not (s["min_age"] <= age <= s["max_age"]):
        return False

    # Income: 0 means no income ceiling stored.
    if s["max_income"] > 0 and income > s["max_income"]:
        return False

    # Gender
    if s["gender"] not in ("All", gender):
        return False

    # Occupation
    if s["occupation"] not in ("All", occupation):
        return False

    # Student / farmer flags are requirements only when set to 1.
    if s["student"] == 1 and not student:
        return False
    if s["farmer"] == 1 and not farmer:
        return False

    # Category: All is open to everyone; otherwise allow a matching category.
    if s["category"] not in ("All", category):
        return False

    return True

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/assistant")
def assistant():
    return render_template("assistant.html")

@app.route("/recommend", methods=["POST"])
def recommend():
    try:
        age = int(request.form.get("age", 0))
        income = int(request.form.get("income", 0))
        gender = request.form.get("gender", "All")
        occupation = request.form.get("occupation", "All")
        location = request.form.get("location", "Rural")
        category = request.form.get("category", "All")
        state = request.form.get("state", "Karnataka")
        student = request.form.get("student") == "yes"
        farmer = request.form.get("farmer") == "yes"

        conn = get_db()
        schemes = conn.execute("SELECT * FROM schemes ORDER BY state DESC, name").fetchall()
        conn.close()

        results = [
            dict(s) for s in schemes
            if scheme_matches(s, age, income, gender, occupation, location,
                              category, state, student, farmer)
        ]

        # If no strict matches, return useful nearby matches based on age/state.
        if not results:
            results = [
                dict(s) for s in schemes
                if s["state"] in ("ALL", state)
                and s["min_age"] <= age <= s["max_age"]
            ][:12]

        return render_template(
            "results.html",
            results=results,
            count=len(results),
            language=request.form.get("language", "en")
        )
    except Exception as e:
        return f"Recommendation error: {e}", 500

@app.route("/api/schemes")
def api_schemes():
    conn = get_db()
    rows = conn.execute("SELECT * FROM schemes ORDER BY name").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/ai-chat", methods=["POST"])
def ai_chat():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    language = data.get("language", "English")

    if not message:
        return jsonify({"reply": "Please enter a question."})

    if client is None:
        return jsonify({
            "reply": "AI is not configured yet. Add GEMINI_API_KEY to your .env file and restart Flask."
        }), 503

    conn = get_db()
    rows = conn.execute("""
        SELECT name, description, benefits, eligibility, documents,
               application_process, occupation, min_age, max_age,
               max_income, location, category, gender, student,
               farmer, state, official_link
        FROM schemes
    """).fetchall()
    conn.close()

    # Keep the context compact while still grounding the answer in the local DB.
    context = "\n\n".join(
        f"""Scheme: {r['name']}
Government: {"Central" if r['state']=="ALL" else "Karnataka"}
Description: {r['description']}
Benefits: {r['benefits']}
Eligibility: {r['eligibility']}
Documents: {r['documents']}
Application: {r['application_process']}
Official link: {r['official_link']}"""
        for r in rows
    )

    prompt = f"""
You are Scheme Sahayak, a helpful assistant for Indian government schemes.

Answer in {language}.
Use ONLY the scheme database context below for scheme-specific facts.
Do not invent a scheme, benefit, eligibility rule, application URL, amount,
deadline, or document. If the database does not contain the answer, say so.
Encourage the user to verify current rules on the official link before applying.
Use simple, accessible language. You may use bullets.

DATABASE:
{context}

USER:
{message}
"""

    try:
        response = client.models.generate_content(
            model="gemini-3.6-flash",
            contents=prompt
        )
        return jsonify({"reply": response.text or "I couldn't generate an answer."})
    except Exception as e:
        print("Gemini error:", e)
        return jsonify({"reply": "The AI service could not answer right now. Please try again."}), 500

if __name__ == "__main__":
    app.run(debug=True)
