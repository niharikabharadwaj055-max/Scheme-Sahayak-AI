# Scheme Sahayak — AI Government Scheme Finder

A Flask + SQLite project with:
- Modern responsive UI
- Central Government + Karnataka schemes
- 3-language UI: English, Kannada, Hindi
- Rule-based scheme matching
- Gemini AI assistant grounded on the local SQLite scheme database
- Official portal links
- Mobile-friendly design

## Run

1. Install Python 3.11+.
2. Open this folder in VS Code.
3. Create a virtual environment (recommended):

   python -m venv .venv
   .venv\Scripts\activate

4. Install dependencies:

   python -m pip install -r requirements.txt

5. Copy `.env.example` to `.env` and add your Gemini API key.

6. Initialize the database:

   python database.py

7. Start Flask:

   python app.py

8. Open:

   http://127.0.0.1:5000

AI page:

   http://127.0.0.1:5000/assistant

## Important

The database is seeded with a starter set of 40+ schemes. Government eligibility,
benefits, deadlines and application procedures can change. The UI therefore
links to official portals and the AI is instructed not to invent scheme facts.

Do not commit `.env` or expose your Gemini API key.
